export LD_LIBRARY_PATH=/usr/local/cuda-9.2/lib64:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/opt/anaconda3/lib:$LD_LIBRARY_PATH